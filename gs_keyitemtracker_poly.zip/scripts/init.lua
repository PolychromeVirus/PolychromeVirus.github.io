--  Load configuration options up front
ScriptHost:LoadScript("scripts/settings.lua")

print("Active Variant:")
print(Tracker.ActiveVariantUID)

Tracker:AddItems("items/djinni.json")
Tracker:AddItems("items/common.json")
Tracker:AddItems("items/psynergy.json")

Tracker:AddMaps("maps/maps.json")
Tracker:AddLocations("locations/weyard_logic.json")

Tracker:AddLayouts("layouts/items.json")
Tracker:AddLayouts("layouts/tracker.json")

Tracker:AddLayouts("layouts/standard_broadcast.json")
